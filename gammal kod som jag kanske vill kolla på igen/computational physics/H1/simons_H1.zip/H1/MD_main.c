#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "initfcc.h"
#include "alpotential.h"
#include "verlet_funcs.h"
#include "utility_funcs.h"

/* define some shorthands */
#define kB (8.617e-5) // Boltzmann constant [eV / K]
#define Al_MASS 0.0027964394 // [eV ps² / Å²]
#define Nc 4
#define NBR_CELLS (Nc * Nc * Nc)
#define NBR_ATOMS (4 * NBR_CELLS)
#define a0_LIST_LENGTH 45

/* declare some variables */
double a0;


void task1() {
	double positions[NBR_ATOMS][3]; // [Å]
	double a0; // [Å]
	double a0_list[a0_LIST_LENGTH];
	double potential_energy; // [eV]

	/*declare variable to sum over */
	int i;

	FILE *potential_energy_file;
	FILE *a0_file;

	/* Assign list of unit cell lengths */
	for (i = 0; i < a0_LIST_LENGTH; i++) {
		a0_list[i] = pow(64.0 + 0.1 * i, 1 / 3.0); // in order to match Fig 1
	}

	potential_energy_file = fopen("potential_energy.txt", "w");
	a0_file = fopen("a0.txt", "w");

	/* Calculate potential energies */
	for (i = 0; i < a0_LIST_LENGTH; i++) {
		a0 = a0_list[i];
		init_fcc(positions, Nc, a0);
		potential_energy = get_energy_AL(positions, Nc * a0, NBR_ATOMS);

		/* write energies to file */
		fprintf(potential_energy_file, "%e\n", potential_energy / NBR_CELLS); // potential energy per unit cell
		fprintf(a0_file, "%e\n", a0);
   }

   fclose(potential_energy_file);
   fclose(a0_file);
}


void task2() {
	double positions[NBR_ATOMS][3]; // [Å]
	double velocities [NBR_ATOMS][3]; // [Å / ps]
	double accelerations [NBR_ATOMS][3]; // [Å / ps²]
	double forces [NBR_ATOMS][3]; // [eV / Å]
	double disturbance; // [Å]
	int i, j; // variables to sum over

	/* Initiate some variables */	
	int nbr_timesteps = pow(2, 12) - 1;
	double dt = 1e-5;
	a0 = pow(66.0, 1 / 3.0);

	/* Allocate some memory & declare some files for storing result from Verlet algorithm */
	double *potential_energies = malloc((nbr_timesteps - 1) * sizeof(double));
	double *kinetic_energies = malloc((nbr_timesteps - 1) * sizeof(double));
	FILE *potential_energies_file;
	FILE *kinetic_energies_file;
	FILE *parameters;


	/* Initiate positions & introduce disturbances */
	init_fcc(positions, Nc, a0);
	for (i = 0; i < NBR_ATOMS; i++){
		for (j = 0; j < 3; j++) {
			disturbance = 2 * 0.065 * (0.5 - (double) rand() / (double) RAND_MAX) * a0; // +-6.5% of a0 in each direction
			positions[i][j] += disturbance;
		}
	}

	/* Initiate velocities & accelerations */
	get_forces_AL(forces, positions, Nc * a0, NBR_ATOMS);
	init_vel_acc(velocities, accelerations, forces);


	/* Perform velocity Verlet algorithm */
	for (i = 1; i < nbr_timesteps + 1; i++) {
		/* Update positions, velocities, & accelerations using forces */
		verlet_single(positions, velocities, accelerations, forces, dt);

		/* Update forces */
		get_forces_AL(forces, positions, Nc * a0, NBR_ATOMS);

		/* Calculate & store energies */
		potential_energies[i-1] = get_energy_AL(positions, Nc * a0, NBR_ATOMS);
		kinetic_energies[i-1] = get_kinetic_energy(velocities, NBR_ATOMS);
	}


	/* write energies to file */
	potential_energies_file = fopen("potential_energies_task2.bin", "w");
	kinetic_energies_file = fopen("kinetic_energies_task2.bin", "w");
	parameters = fopen("parameters_task2.bin", "w");

	fwrite(potential_energies, sizeof(double), nbr_timesteps, potential_energies_file);
	fwrite(kinetic_energies, sizeof(double), nbr_timesteps, kinetic_energies_file);
    double paramList[4] = {nbr_timesteps * 1.0, dt, NBR_ATOMS, a0};
    fwrite(paramList, sizeof(double), 4, parameters);

    fclose(potential_energies_file);
    fclose(kinetic_energies_file);
    fclose(parameters);

	free(potential_energies);
	free(kinetic_energies);
}


void task3() {
	double positions[NBR_ATOMS][3]; // [Å]
	double velocities [NBR_ATOMS][3]; // [Å / ps]
	double accelerations [NBR_ATOMS][3]; // [Å / ps²]
	double forces [NBR_ATOMS][3]; // [eV / Å]
	double disturbance; // [Å]
	double temperature = 0.0; // these two are initiated in order to silence some warnings
	double pressure = 0.0;
	int i, j; // variables to sum over

	/* Initiate some variables */	
	int nbr_timesteps_per_epoch = pow(2, 12) - 1;
	int nbr_epochs = 30;
	double dt = 1e-5;
	a0 = pow(66.0, 1 / 3.0);
	double T_eq = 773.2; // [K]
	double P_eq = 6.242e-7; // [eV / Å³]
	double T_decay_constant = 100.0; // [ps⁻¹]
	double P_decay_constant = 100.0; // [ps⁻¹]

	/* Variables for writing to file */
	double temperatures[nbr_epochs];
	double pressures[nbr_epochs];
	FILE *temperatures_file;
	FILE *pressures_file;
	FILE *parameters_file;


	/* Initiate positions & introduce disturbances */
	init_fcc(positions, Nc, a0);
	for (i = 0; i < NBR_ATOMS; i++){
		for (j = 0; j < 3; j++) {
			disturbance = 2 * 0.065 * (0.5 - (double) rand() / (double) RAND_MAX) * a0; // +-6.5% of a0 in each direction
			positions[i][j] += disturbance;
		}
	}

	/* Initiate velocities & accelerations */
	get_forces_AL(forces, positions, Nc * a0, NBR_ATOMS);
	init_vel_acc(velocities, accelerations, forces);

	/* Equilibrate the lattice */
	for (i = 1; i < nbr_epochs + 1; i++) {

		/* Perform one epoch of velocity Verlet algorithm.
		temperature & pressure are calculated from time averages. */
		verlet_task3(temperature, pressure, positions, velocities, accelerations, a0, dt, nbr_timesteps_per_epoch);

		/* Update positions & velocities */
		temperature = get_temperature(velocities, NBR_ATOMS);
		pressure = get_pressure();
		equilibration_update(positions, velocities, temperature, pressure, T_eq, P_eq, T_decay_constant, P_decay_constant, dt);

		/* Save temperatures & pressures for later */
		temperatures[i-1] = temperature;
		pressures[i-1] = pressure;
	}

	/* Write temperatures & pressures to file */
	temperatures_file = fopen("temperatures_task3.bin", "w");
	pressures_file = fopen("pressures_task3.bin", "w");
	parameters_file = fopen("parameters_task3.bin", "w");

	fwrite(temperatures, sizeof(double), nbr_epochs, temperatures_file);
	fwrite(pressures, sizeof(double), nbr_epochs, pressures_file);
	double parameters[4] = {(double) nbr_timesteps_per_epoch, (double) nbr_epochs, T_decay_constant, P_decay_constant};
	fwrite(parameters, sizeof(double), 4, parameters_file);

	fclose(temperatures_file);
	fclose(pressures_file);
	fclose(parameters_file);
}


/* Main program */
int main()
{
	/* Initiate RNG */
	srand(time(NULL));

	// task1();

	// task2();

	 task3();


	/*
		Descriptions of the different functions in the files initfcc.c and
		alpotential.c are listed below.
	*/

	/* 
		Function that generates a fcc lattice in units of [Å]. Nc is the number of 
		primitive cells in each direction and a0 is the lattice parameter. The
		positions of all the atoms are stored in pos which should be a matrix of the
		size N x 3, where N is the number of atoms. The first, second and third column
		correspond to the x,y and z coordinate respectively.
	*/

	


	/* 
		Function that calculates the potential energy in units of [eV]. pos should be
		a matrix containing the positions of all the atoms, L is the length of the 
		supercell and N is the number of atoms.
	*/
	
	
	

	/* 
		Function that calculates the virial in units of [eV]. pos should be a matrix
		containing the positions of all the atoms, L is the length of the supercell 
		and N is the number of atoms.
	*/
	/*
		double virial;
		virial = get_virial_AL(pos, L, N);
	*/



   return 0;
}





