
double get_kinetic_energy(double velocities[][3], int velocities_length);
double get_temperature(double velocities[][3], int velocities_length);
double get_pressure();
void equilibration_update(double positions[][3], double velocities[][3], double temperature, double pressure, double T_eq, double P_eq, double T_decay_constant, double P_decay_constant, double timestep);
