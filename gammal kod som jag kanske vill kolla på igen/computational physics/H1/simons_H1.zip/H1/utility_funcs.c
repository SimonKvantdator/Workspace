#include "utility_funcs.h"

#include <stdio.h>
#include <math.h>
#include "verlet_funcs.h"

/* define some shorthands (same as in main) */
#define kB (8.617e-5) // Boltzmann constant [eV / K]
#define Al_MASS 0.0027964394 // [eV ps² / Å²]
#define Nc 4
#define NBR_CELLS (Nc * Nc * Nc)
#define NBR_ATOMS (4 * NBR_CELLS)
#define a0_LIST_LENGTH 45


/* Returns total kinetic energy of supercell */
double get_kinetic_energy(double velocities[][3], int velocities_length) {
	/* Declare variable to sum over */
	int i;

	/* Initiate sum of kinetic enrgies */
	double sum = 0.0;

	for (i = 0; i < velocities_length; i++){
		sum += 0.5 * pow(velocities[i][0], 2) * Al_MASS;
		sum += 0.5 * pow(velocities[i][1], 2) * Al_MASS;
		sum += 0.5 * pow(velocities[i][2], 2) * Al_MASS;
	}

	return sum;
}


/* Returns temperature of supercell */
double get_temperature(double velocities[][3], int velocities_length) {
	double average_kinetic_energy;
	double temperature;

	average_kinetic_energy = get_kinetic_energy(velocities, velocities_length) / velocities_length;
	temperature = average_kinetic_energy * 2.0 / (3.0 * kB);
	
	return temperature;
}


/* Returns pressure of supercell */
double get_pressure() {
	return NAN; // TODO
}


/* Updates positions & velocities using temperature & pressure to better match T_eq & P_eq */
void equilibration_update(double positions[][3], double velocities[][3], double temperature, double pressure, double T_eq, double P_eq, double T_decay_constant, double P_decay_constant, double timestep) {
	double alpha_T;
	double alpha_P;
	int i; // variable to sum over

	/* Calculate rescaling factors */
	alpha_T = 1.0 + 2.0 * timestep * (T_eq - temperature) / (T_decay_constant * temperature);
	alpha_P = NAN; // TODO
	
	/* Rescale velocitites in order to get closer to T_eq */ 
	for (i = 0; i < NBR_ATOMS; i++) {
		velocities[i][0] *= pow(alpha_T, 1 / 3.0);
		velocities[i][1] *= pow(alpha_T, 1 / 3.0);
		velocities[i][2] *= pow(alpha_T, 1 / 3.0);

        // positions[i][0] *= pow(alpha_P, 1 / 2.0);
        // positions[i][1] *= pow(alpha_P, 1 / 2.0);
        // positions[i][2] *= pow(alpha_P, 1 / 2.0);
	}
}