ax.plot(t, kinetic_energies, label=r'kinetic energy')
ax.plot(t, total_energies, label=r'total energy')
