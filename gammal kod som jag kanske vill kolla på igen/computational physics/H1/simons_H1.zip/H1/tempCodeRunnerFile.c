        // positions[i][0] *= pow(alpha_P, 1 / 2.0);
        // positions[i][1] *= pow(alpha_P, 1 / 2.0);
        // positions[i][2] *= pow(alpha_P, 1 / 2.0);
