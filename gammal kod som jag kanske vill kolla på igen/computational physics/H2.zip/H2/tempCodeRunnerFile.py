alphas = np.fromfile("alphas_task3.bin")
energies = np.fromfile("energies_task3.bin") # energies[walker_index + alpha_index * nbr_walkers
variances = np.fromfile("variances_task3.bin") # variances[walker_index + alpha_index * nbr_walkers
parameters = np.fromfile("parameters_task1.bin") # {alpha, Delta, nbr_samples, nbr_walkers}

### extract parameters ###
nbr_samples = int(parameters[2])
nbr_walkers = int(parameters[3])
alphas_length = len(alphas)