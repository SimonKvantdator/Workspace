) 
			* exp(